# eCommerce site using Node Express js & Mysql (SQL file included)
This is a basic eCommrece website.

1. Bootstrap 4 design - Done
2. Product listing - Done
3. Add to cart - Done
4. Product details - Done
5. Cart page - Done
6. Update cart - Done
7. Remove from cart - Done
8. Checkout page - Working...

# Screenshots

Products list page
![alt ProductsPage](https://sendmail2krrish.github.io/eCommerce-site-using-Node-Express-js/Screenshots/pic1.png)

Product details page
![alt ProductDetails](https://sendmail2krrish.github.io/eCommerce-site-using-Node-Express-js/Screenshots/pic2.png)

Cart page
![alt Cart](https://sendmail2krrish.github.io/eCommerce-site-using-Node-Express-js/Screenshots/pic3.png)

Checkout page
![alt Checkout](https://sendmail2krrish.github.io/eCommerce-site-using-Node-Express-js/Screenshots/pic4.png)


Thanks,<br />
Krishna<br />
<a href="mailto:sendmail2krrish@gmail.com">sendmail2krrish@gmail.com</a>